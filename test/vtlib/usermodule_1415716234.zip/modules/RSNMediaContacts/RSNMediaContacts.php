<?php
/***********************************************************************************
 * The contents of this file are subject to the vtiger CRM Public License Version 1.0
 * ("License"); You may not use this file except in compliance with the License
 * The Original Code is:  vtiger CRM Open Source
 * The Initial Developer of the Original Code is vtiger.
 * Portions created by vtiger are Copyright (C) vtiger.
 * All Rights Reserved.
 ************************************************************************************/

include_once 'modules/Vtiger/CRMEntity.php';

class RSNMediaContacts extends Vtiger_CRMEntity {
	var $table_name = 'vtiger_rsnmediacontacts';
	var $table_index= 'rsnmediacontactsid';

	/**
	 * Mandatory table for supporting custom fields.
	 */
	var $customFieldTable = Array('vtiger_rsnmediacontactscf', 'rsnmediacontactsid');

	/**
	 * Mandatory for Saving, Include tables related to this module.
	 */
	var $tab_name = Array('vtiger_crmentity', 'vtiger_rsnmediacontacts', 'vtiger_rsnmediacontactscf');

	/**
	 * Mandatory for Saving, Include tablename and tablekey columnname here.
	 */
	var $tab_name_index = Array(
		'vtiger_crmentity' => 'crmid',
		'vtiger_rsnmediacontacts' => 'rsnmediacontactsid',
		'vtiger_rsnmediacontactscf'=>'rsnmediacontactsid');

	/**
	 * Mandatory for Listing (Related listview)
	 */
	var $list_fields = array (
		'LBL_RSNMEDIAID' => array('rsnmediacontacts', 'rsnmediaid'),
		'LBL_CONTACTEMAIL' => array('rsnmediacontacts', 'contactemail'),
		'LBL_CONTACTMEDIACOMMENT' => array('rsnmediacontacts', 'contactmediacomment'),
		'LBL_DERNIERCONTACT' => array('rsnmediacontacts', 'derniercontact'),
		'LBL_RSNTYPESCONTACTMEDIA' => array('rsnmediacontacts', 'rsntypescontactmedia'),
		'LBL_NOM' => array('rsnmediacontacts', 'nom'),
		'LBL_CONTACTPHONE' => array('rsnmediacontacts', 'contactphone'),
		'LBL_RSNMEDIADOCUMENTS' => array('rsnmediacontacts', 'rsnmediadocuments'),
		'LBL_RSNTHEMATIQUES' => array('rsnmediacontacts', 'rsnthematiques'),
		'LBL_RUBRIQUE' => array('rsnmediacontacts', 'rubrique'),
		'LBL_RSNCOUNTRY' => array('rsnmediacontacts', 'rsncountry'),
		'LBL_INTERETS' => array('rsnmediacontacts', 'interets'),
		'LBL_RSNREGION' => array('rsnmediacontacts', 'rsnregion'),

);
	var $list_fields_name = array (
		'LBL_RSNMEDIAID' => 'rsnmediaid',
		'LBL_CONTACTEMAIL' => 'contactemail',
		'LBL_CONTACTMEDIACOMMENT' => 'contactmediacomment',
		'LBL_DERNIERCONTACT' => 'derniercontact',
		'LBL_RSNTYPESCONTACTMEDIA' => 'rsntypescontactmedia',
		'LBL_NOM' => 'nom',
		'LBL_CONTACTPHONE' => 'contactphone',
		'LBL_RSNMEDIADOCUMENTS' => 'rsnmediadocuments',
		'LBL_RSNTHEMATIQUES' => 'rsnthematiques',
		'LBL_RUBRIQUE' => 'rubrique',
		'LBL_RSNCOUNTRY' => 'rsncountry',
		'LBL_INTERETS' => 'interets',
		'LBL_RSNREGION' => 'rsnregion',

);

	// Make the field link to detail view
	var $list_link_field = '';

	// For Popup listview and UI type support
	var $search_fields = array (
		'LBL_RSNREGION' => array('rsnmediacontacts', 'rsnregion'),
		'LBL_RSNMEDIAID' => array('rsnmediacontacts', 'rsnmediaid'),
		'LBL_RSNTHEMATIQUES' => array('rsnmediacontacts', 'rsnthematiques'),
		'LBL_RUBRIQUE' => array('rsnmediacontacts', 'rubrique'),
		'LBL_INTERETS' => array('rsnmediacontacts', 'interets'),
		'LBL_RSNCOUNTRY' => array('rsnmediacontacts', 'rsncountry'),
		'LBL_RSNMEDIADOCUMENTS' => array('rsnmediacontacts', 'rsnmediadocuments'),
		'LBL_CONTACTMEDIACOMMENT' => array('rsnmediacontacts', 'contactmediacomment'),
		'LBL_CONTACTEMAIL' => array('rsnmediacontacts', 'contactemail'),
		'LBL_DERNIERCONTACT' => array('rsnmediacontacts', 'derniercontact'),
		'LBL_RSNTYPESCONTACTMEDIA' => array('rsnmediacontacts', 'rsntypescontactmedia'),
		'LBL_CONTACTPHONE' => array('rsnmediacontacts', 'contactphone'),
		'LBL_NOM' => array('rsnmediacontacts', 'nom'),

);
	var $search_fields_name = array (
		'LBL_RSNREGION' => 'rsnregion',
		'LBL_RSNMEDIAID' => 'rsnmediaid',
		'LBL_RSNTHEMATIQUES' => 'rsnthematiques',
		'LBL_RUBRIQUE' => 'rubrique',
		'LBL_INTERETS' => 'interets',
		'LBL_RSNCOUNTRY' => 'rsncountry',
		'LBL_RSNMEDIADOCUMENTS' => 'rsnmediadocuments',
		'LBL_CONTACTMEDIACOMMENT' => 'contactmediacomment',
		'LBL_CONTACTEMAIL' => 'contactemail',
		'LBL_DERNIERCONTACT' => 'derniercontact',
		'LBL_RSNTYPESCONTACTMEDIA' => 'rsntypescontactmedia',
		'LBL_CONTACTPHONE' => 'contactphone',
		'LBL_NOM' => 'nom',

);

	// For Popup window record selection
	var $popup_fields = array('');

	// For Alphabetical search
	var $def_basicsearch_col = '';

	// Column value to use on detail view record text display
	var $def_detailview_recname = '';

	// Used when enabling/disabling the mandatory fields for the module.
	// Refers to vtiger_field.fieldname values.
	var $mandatory_fields = array('createdtime', 'modifiedtime', '');

	var $default_order_by = '';
	var $default_sort_order='ASC';

	function RSNMediaContacts() {
		$this->log =LoggerManager::getLogger('RSNMediaContacts');
		$this->db = PearDatabase::getInstance();
		$this->column_fields = getColumnFields('RSNMediaContacts');
	}

	/**
	* Invoked when special actions are performed on the module.
	* @param String Module name
	* @param String Event Type
	*/
	function vtlib_handler($moduleName, $eventType) {
 		if($eventType == 'module.postinstall') {
			//Delete duplicates from all picklist
			static::deleteDuplicatesFromAllPickLists($moduleName);
		} else if($eventType == 'module.disabled') {
			// TODO Handle actions before this module is being uninstalled.
		} else if($eventType == 'module.preuninstall') {
			// TODO Handle actions when this module is about to be deleted.
		} else if($eventType == 'module.preupdate') {
			// TODO Handle actions before this module is updated.
		} else if($eventType == 'module.postupdate') {
			//Delete duplicates from all picklist
			static::deleteDuplicatesFromAllPickLists($moduleName);
		}
 	}
	
	/**
	 * Delete doubloons from all pick list from module
	 */
	public static function deleteDuplicatesFromAllPickLists($moduleName)
	{
		global $adb,$log;

		$log->debug("Invoking deleteDuplicatesFromAllPickList(".$moduleName.") method ...START");

		//Deleting doubloons
		$query = "SELECT columnname FROM `vtiger_field` WHERE uitype in (15,16,33) "
				. "and tabid in (select tabid from vtiger_tab where name = '$moduleName')";
		$result = $adb->pquery($query, array());

		$a_picklists = array();
		while($row = $adb->fetchByAssoc($result))
		{
			$a_picklists[] = $row["columnname"];
		}
		
		foreach ($a_picklists as $picklist)
		{
			static::deleteDuplicatesFromPickList($picklist);
		}
		
		$log->debug("Invoking deleteDuplicatesFromAllPickList(".$moduleName.") method ...DONE");
	}
	
	public static function deleteDuplicatesFromPickList($pickListName)
	{
		global $adb,$log;
		
		$log->debug("Invoking deleteDuplicatesFromPickList(".$pickListName.") method ...START");
	
		//Deleting doubloons
		$query = "SELECT {$pickListName}id FROM vtiger_{$pickListName} GROUP BY {$pickListName}";
		$result = $adb->pquery($query, array());
	
		$a_uniqueIds = array();
		while($row = $adb->fetchByAssoc($result))
		{
			$a_uniqueIds[] = $row[$pickListName.'id'];
		}
	
		if(!empty($a_uniqueIds))
		{
			$query = "DELETE FROM vtiger_{$pickListName} WHERE {$pickListName}id NOT IN (".implode(",", $a_uniqueIds).")";
			$adb->pquery($query, array());
		}
		
		$log->debug("Invoking deleteDuplicatesFromPickList(".$pickListName.") method ...DONE");
	}
}